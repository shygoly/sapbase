# DECISIONS.md — 架构决策记录

> **机器可校验的决策登记**。代码里的 `D-x` 标记（词边界，非 `TD-x`）必须在此注册，
> 校验由 `node scripts/check-meta-docs.mjs` 强制。新增决策按 D-x 递增编号，
> 格式用 `yaml decision` 围栏块。
> **命名空间约定**：`D-x` = 架构决策（本册）；`TD-x` = 技术债（`docs/tech-debt.md`，
> 不入本册）；`INV-x` = 不变量（`DOMAIN.md`）。三者正交，禁止混用前缀。

---

## 已收编决策

### D-1：发布不可变

```yaml decision
id: D-1
title: 发布不可变，修复必须发新版本
status: accepted
date: 2026-10
context: |
  早期“发布”只是上传 Blueprint 包，覆盖同名版本；出问题无法复现，
  也无法判断某个租户到底跑的是哪份定义。
decision: |
  app_releases 的 published 行只读；内容字段由数据库触发器拒绝 UPDATE。
  任何修复产生新的 semver + 新 digest；回退 = 重新激活旧 release。
references:
  - INV-REL-01
  - INV-REL-07
  - docs/reference/04-versioning-release.md
code_markers:
  - libs/release-kernel/src/lib/publish.service.ts
  - libs/release-kernel/src/lib/activate.service.ts
```

### D-2：保留 TypeORM，不在 Nx 迁移中换 ORM

```yaml decision
id: D-2
title: 保留 TypeORM，不在 Nx 迁移中更换 ORM
status: accepted
date: 2026-10
context: |
  Nx 迁移与 ORM 更换同时进行会把结构问题与数据访问问题混在一起；
  现有 Blueprint/RLS/审计代码与 TypeORM 实体耦合较深。
decision: |
  Nx 迁移不更换 ORM；新增代码继续用 TypeORM。
  若未来引入 Prisma，按限界上下文逐个迁移，不允许同一上下文混用。
references:
  - docs/reference/02-architecture.md §10
code_markers:
  - backend/src/common/database
```

### D-3：PiAgent 只能经工具面操作

```yaml decision
id: D-3
title: PiAgent 只能经工具面操作，不得直连数据库
status: accepted
date: 2026-10
context: |
  直连数据库会绕过权限、确认令牌与审计；模型生成 SQL 还会引入注入与性能风险。
decision: |
  PiAgent 的所有业务读写必须经 contracts/tools.json 声明的工具；
  写操作必须一次性确认令牌；权限 all-of 由平台判定。
references:
  - INV-AGENT-01
  - INV-AGENT-02
  - docs/protocols/chat-erp.md
code_markers:
  - backend/src/agent-tools/agent-tool.registry.ts
  - libs/agent-tools/src
```

### D-4：作者 ≠ 批准人

```yaml decision
id: D-4
title: 提议作者不得批准/发布自己的提议
status: accepted
date: 2026-10
context: |
  Builder Agent 可以起草提议；若它也能批准，治理闭环失效，审计无法区分“建议”与“决定”。
decision: |
  审批与发布必须由有权限的人完成；服务端校验 approver ≠ author。
  高风险变更（权限/工具/知识/迁移）需要第二审批人。
references:
  - INV-AGENT-04
  - INV-EVO-02
code_markers:
  - libs/release-kernel/src/lib/approve.service.ts
```

---

## 附录：命名空间约定

| 前缀 | 含义 | 归属 | 校验 |
|---|---|---|---|
| `D-x` | 架构决策（不可逆的设计选择） | 本册 | `check:meta`（代码 D-x 标记必须在册） |
| `TD-x` | 技术债（待偿还的妥协） | `docs/tech-debt.md` | 无校验（债务，非契约） |
| `INV-x` | 不变量（运行时必须成立的约束） | `DOMAIN.md` / `01-meta-model.md` | `check:domain`（spec/enforcement 对拍） |

三者正交：同一个设计点可能同时有 D-x（决策）+ INV-x（不变量），但编号独立。
