# 航道碳排放管理系统 - 完整数据库表设计（适配脚手架规范）

本文档根据现有脚手架规范重新设计航运碳管理模块的数据表，确保继承关系、字段命名、多租户隔离与脚手架一致。所有表均包含 `createdAt` 和 `updatedAt` 审计字段（由基类自动提供，下文省略）。

---

## 1. 基础结构与继承体系

- **BaseEntity**：提供 `id` (UUID PK), `createdAt`, `updatedAt`
- **TenantAwareEntity**：继承 BaseEntity，添加 `organizationId` (UUID FK) 及 `organization` 多对一关系，用于租户隔离。

所有租户级数据均继承 `TenantAwareEntity`，全局数据继承 `BaseEntity`。  
对需要“全局+租户私有并存”的主数据表（如 `fuel_types`、`fuel_prices`），采用 **BaseEntity + nullable organizationId** 模式：
- `organizationId IS NULL` 表示全局数据
- `organizationId = <租户ID>` 表示租户私有数据

---

## 2. 船舶与租期

### `vessels`（船舶） — 全局
| 字段名 | 类型 | 约束 | 说明 |
|--------|------|------|------|
| id | uuid | PK | 继承 BaseEntity |
| imo | varchar(20) | UNIQUE NOT NULL | IMO编号 |
| name | varchar(100) | NOT NULL | 船名 |
| shipType | varchar(50) | NOT NULL | 船型，关联 `ship_type_params.shipType` |
| gt | numeric(10,2) | NOT NULL | 总吨位（吨） |
| dwt | numeric(10,2) | NOT NULL | 载重吨（吨） |
| cruisingSpeed | numeric(5,2) | | 巡航速度（节），可选 |
| windAssist | boolean | DEFAULT false | 是否安装风力辅助设备 |
| windAssistDeviceType | varchar(50) | FK -> wind_assist_factors.deviceType, nullable | 风力辅助设备类型（如 Rotor sail），用于确定奖励因子 |

索引：
- `idx_vessels_imo` (imo)

### `charter_periods`（租期） — 租户级
继承 `TenantAwareEntity`
| 字段名 | 类型 | 约束 | 说明 |
|--------|------|------|------|
| id | uuid | PK |  |
| organizationId | uuid | FK -> organizations.id NOT NULL | 租户ID（租用方） |
| vesselId | uuid | FK -> vessels.id NOT NULL | 船舶ID |
| startDate | date | NOT NULL | 租期开始日期 |
| endDate | date | NOT NULL | 租期结束日期 |

约束：
- 同一 `vesselId` 的租期不能重叠（应用层或数据库触发器保证）
索引：
- `idx_charter_periods_vessel` (vesselId)
- `idx_charter_periods_organization` (organizationId)

---

## 3. 港口（全局）

### `ports`（港口） — 全局
继承 `BaseEntity`
| 字段名 | 类型 | 约束 | 说明 |
|--------|------|------|------|
| id | uuid | PK |  |
| code | varchar(10) | UNIQUE NOT NULL | 港口代码，如 'BEZEE' |
| name | varchar(100) | NOT NULL | 港口名称 |
| country | varchar(50) | NOT NULL | 国家 |
| isEu | boolean | NOT NULL | 是否属于欧盟港口 |

索引：
- `idx_ports_code` (code)

---

## 4. 航次与燃料消耗

### `voyages`（航次） — 租户级
继承 `TenantAwareEntity`
| 字段名 | 类型 | 约束 | 说明 |
|--------|------|------|------|
| id | uuid | PK |  |
| organizationId | uuid | FK -> organizations.id NOT NULL | 所属租户（导入时确定） |
| vesselId | uuid | FK -> vessels.id NOT NULL | 船舶ID |
| charterPeriodId | uuid | FK -> charter_periods.id, nullable | 认领后的租期ID，未认领为null |
| status | varchar(20) | NOT NULL | 状态：'unclaimed','claimed','calculated','locked' |
| startPortCode | varchar(10) | FK -> ports.code NOT NULL | 起始港口代码 |
| endPortCode | varchar(10) | FK -> ports.code NOT NULL | 目的港口代码 |
| departureTime | timestamptz | NOT NULL | 离港时间 |
| arrivalTime | timestamptz | NOT NULL | 到港时间 |
| routeDistance | numeric(10,2) | NOT NULL | 航行距离（海里） |
| shorePowerConsumption | numeric(10,2) | DEFAULT 0 | 岸电消耗量（MJ） |
| arrivalPurpose | varchar(100) | | 抵港目的（如 'Routine voyage'） |
| throughIce | boolean | DEFAULT false | 是否冰区航行（仅展示） |

索引：
- `idx_voyages_vessel_departure` (vesselId, departureTime)
- `idx_voyages_organization` (organizationId)
- `idx_voyages_status` (status)

### `voyage_fuels`（航次燃料消耗） — 非租户级（通过 voyage 关联）
继承 `BaseEntity`
| 字段名 | 类型 | 约束 | 说明 |
|--------|------|------|------|
| id | uuid | PK |  |
| voyageId | uuid | FK -> voyages.id NOT NULL | 航次ID |
| fuelTypeCode | varchar(20) | FK -> fuel_types.code NOT NULL | 燃料类型代码 |
| consumption | numeric(10,3) | NOT NULL | 消耗量（吨） |
| isMain | boolean | NOT NULL | true=主燃料，false=辅燃料 |

索引：
- `idx_voyage_fuels_voyage` (voyageId)

---

## 5. 燃料基础数据

### `fuel_types`（燃料类型） — 全局+租户级
继承 `BaseEntity`（`organizationId` 可空，支持全局与租户私有）
| 字段名 | 类型 | 约束 | 说明 |
|--------|------|------|------|
| id | uuid | PK |  |
| organizationId | uuid | FK -> organizations.id, nullable | `NULL`=全局燃料；非空=租户私有燃料 |
| code | varchar(20) | NOT NULL | 燃料代码，如 'HFO' |
| name | varchar(100) | NOT NULL | 燃料名称 |
| category | varchar(50) | NOT NULL | 分类：'RFNBO', '化石', '生物'等 |
| lcv | numeric(10,6) | NOT NULL | 低热值（MJ/gFuel） |
| co2EmissionFactor | numeric(10,6) | NOT NULL | CII CO₂排放因子（gCO₂/gFuel） |
| co2eqWtt | numeric(10,6) | NOT NULL | Well-to-tank CO₂当量（gCO₂eq/MJ） |
| cslip | numeric(5,2) | NOT NULL | 未燃烧燃料系数（%） |
| cfCo2 | numeric(10,6) | NOT NULL | Cf(CO₂)（g/gFuel） |
| cfCh4 | numeric(10,6) | NOT NULL | Cf(CH₄)（g/gFuel） |
| cfN2o | numeric(10,6) | NOT NULL | Cf(N₂O)（g/gFuel） |

唯一约束（建议使用部分唯一索引）：
- `uniq_fuel_types_global_code` (`code`) WHERE organizationId IS NULL
- `uniq_fuel_types_org_code` (`organizationId`, `code`) WHERE organizationId IS NOT NULL
索引：
- `idx_fuel_types_code` (code)
- `idx_fuel_types_org` (organizationId)

### `fuel_prices`（燃料价格） — 全局+租户级
继承 `BaseEntity`（`organizationId` 可空，支持全局与租户私有）
| 字段名 | 类型 | 约束 | 说明 |
|--------|------|------|------|
| id | uuid | PK |  |
| organizationId | uuid | FK -> organizations.id, nullable | `NULL`=全局价格；非空=租户私有价格 |
| fuelTypeId | uuid | FK -> fuel_types.id NOT NULL | 燃料类型ID |
| year | integer | NOT NULL | 年份 |
| priceUsdPerTon | numeric(10,2) | NOT NULL | 美元/吨 |

唯一约束（建议使用部分唯一索引）：
- `uniq_fuel_prices_global_fuel_year` (`fuelTypeId`, `year`) WHERE organizationId IS NULL
- `uniq_fuel_prices_org_fuel_year` (`organizationId`, `fuelTypeId`, `year`) WHERE organizationId IS NOT NULL
索引：
- `idx_fuel_prices_org` (organizationId)
- `idx_fuel_prices_fuel_year` (fuelTypeId, year)

---

## 6. 监管参数（全局）

### `regulation_params`（全局年份减排参数） — 全局
继承 `BaseEntity`
| 字段名 | 类型 | 约束 | 说明 |
|--------|------|------|------|
| id | uuid | PK |  |
| year | integer | UNIQUE NOT NULL | 年份 |
| r | numeric(5,2) | NOT NULL | CII目标减排百分比（如9.0） |
| ghgTarget | numeric(10,6) | NOT NULL | FuelEU GHG目标值（gCO₂eq/MJ） |
| euaPriceEur | numeric(10,2) | NOT NULL | EU ETS碳价（欧元/吨CO₂） |
| excessPenaltyPerTon | numeric(10,2) | NOT NULL | FuelEU超额罚金单价（欧元/吨） |

索引：
- `idx_regulation_params_year` (year)

### `ship_type_params`（船型参数） — 全局
继承 `BaseEntity`
| 字段名 | 类型 | 约束 | 说明 |
|--------|------|------|------|
| id | uuid | PK |  |
| shipType | varchar(50) | UNIQUE NOT NULL | 船型名称，如 'Bulk carrier' |
| capacityBasis | varchar(3) | NOT NULL | CII分母：'DWT' 或 'GT' |
| a | numeric(10,6) | NOT NULL | 参考线常数a |
| c | numeric(10,6) | NOT NULL | 参考线常数c |
| d1 | numeric(10,6) | NOT NULL | 评级边界d1 |
| d2 | numeric(10,6) | NOT NULL | 评级边界d2 |
| d3 | numeric(10,6) | NOT NULL | 评级边界d3 |
| d4 | numeric(10,6) | NOT NULL | 评级边界d4 |

索引：
- `idx_ship_type_params_type` (shipType)

### `cii_compliant_ship_types`（CII合规适用船型） — 全局
继承 `BaseEntity`
| 字段名 | 类型 | 约束 | 说明 |
|--------|------|------|------|
| id | uuid | PK |  |
| shipType | varchar(50) | UNIQUE NOT NULL | 船型名称 |

索引：
- `idx_cii_compliant_type` (shipType)

### `gwp_values`（全球变暖潜能值） — 全局
继承 `BaseEntity`
| 字段名 | 类型 | 约束 | 说明 |
|--------|------|------|------|
| id | uuid | PK |  |
| gas | varchar(10) | UNIQUE NOT NULL | 气体：'CO₂','CH₄','N₂O' |
| gwp | integer | NOT NULL | GWP值：1, 28, 265 |

### `csf_values`（碳减排系数） — 全局
继承 `BaseEntity`
| 字段名 | 类型 | 约束 | 说明 |
|--------|------|------|------|
| id | uuid | PK |  |
| gas | varchar(10) | UNIQUE NOT NULL | 气体：'CO₂','CH₄','N₂O' |
| csf | numeric(5,2) | NOT NULL | 系数：0, 1, 0 |

### `wind_assist_factors`（风力奖励因子） — 全局
继承 `BaseEntity`
| 字段名 | 类型 | 约束 | 说明 |
|--------|------|------|------|
| id | uuid | PK |  |
| deviceType | varchar(50) | UNIQUE NOT NULL | 设备类型，如 'Rotor sail' |
| factor | numeric(5,2) | NOT NULL | 奖励因子 |

### `currency_exchange_rates`（汇率） — 全局
继承 `BaseEntity`
| 字段名 | 类型 | 约束 | 说明 |
|--------|------|------|------|
| id | uuid | PK |  |
| fromCurrency | varchar(3) | NOT NULL | 源币种，如 'EUR' |
| toCurrency | varchar(3) | NOT NULL | 目标币种，如 'USD' |
| rate | numeric(10,6) | NOT NULL | 汇率 |
| effectiveDate | date | NOT NULL | 生效日期 |

唯一约束：
- `uniq_exchange_rate` (fromCurrency, toCurrency, effectiveDate)

### `fuel_eu_ets_cf_co2`（EU ETS Cf CO₂按年份） — 全局
继承 `BaseEntity`
| 字段名 | 类型 | 约束 | 说明 |
|--------|------|------|------|
| id | uuid | PK |  |
| fuelTypeId | uuid | FK -> fuel_types.id NOT NULL | 燃料类型ID |
| year | integer | NOT NULL | 年份 |
| cfCo2Ets | numeric(10,6) | NOT NULL | EU ETS CO₂转化系数（gCO₂/gFuel） |

唯一约束：
- `uniq_ets_cf_fuel_year` (fuelTypeId, year)

---

## 7. 合规历史与快照（租户级）

### `fueleu_compliance_history`（FuelEU超排历史） — 租户级
继承 `TenantAwareEntity`
| 字段名 | 类型 | 约束 | 说明 |
|--------|------|------|------|
| id | uuid | PK |  |
| organizationId | uuid | FK -> organizations.id NOT NULL | 租户ID |
| vesselId | uuid | FK -> vessels.id NOT NULL | 船舶ID |
| year | integer | NOT NULL | 年份 |
| isNonCompliant | boolean | NOT NULL | 当年是否超排 |
| penaltyMultiplier | numeric(3,1) | NOT NULL | 当年实际使用的惩罚系数 |

唯一约束：
- `uniq_fueleu_history_vessel_year` (vesselId, year) — 但因租户隔离，需联合组织？vesselId 全局唯一，所以可以唯一。但组织隔离要求查询时加上 organizationId，索引可包含 organizationId。
索引：
- `idx_fueleu_history_org` (organizationId)
- `idx_fueleu_history_vessel` (vesselId)

### `calculation_snapshots`（计算快照） — 租户级
继承 `TenantAwareEntity`
| 字段名 | 类型 | 约束 | 说明 |
|--------|------|------|------|
| id | uuid | PK |  |
| organizationId | uuid | FK -> organizations.id NOT NULL | 租户ID |
| vesselId | uuid | FK -> vessels.id NOT NULL | 船舶ID |
| year | integer | NOT NULL | 报告年份 |
| reportType | varchar(20) | NOT NULL | 类型：'cii','fueleu','ets','fuelCost' |
| snapshotData | jsonb | NOT NULL | 完整的计算结果（含中间值） |
| inputHash | varchar(64) | NOT NULL | 输入参数哈希，用于判断是否需要重算 |
| regulationParamsVersion | integer | | 当时使用的 regulation_params 年份（或快照ID） |
| fuelPricesVersion | jsonb | | 使用的燃料价格范围（如起始ID） |

索引：
- `idx_calc_snapshots_org_vessel_year` (organizationId, vesselId, year, reportType)

---

## 8. 租户设置与场景模拟

### `organization_settings`（租户设置） — 租户级（与组织一对一）
继承 `TenantAwareEntity`
| 字段名 | 类型 | 约束 | 说明 |
|--------|------|------|------|
| id | uuid | PK |  |
| organizationId | uuid | FK -> organizations.id UNIQUE NOT NULL | 租户ID（一对一） |
| defaultInterEuRatio | numeric(5,2) | DEFAULT 0 | 默认欧盟内部比例（%） |
| defaultIntraEuRatio | numeric(5,2) | DEFAULT 0 | 默认进出欧盟比例（%） |
| defaultExtraEuRatio | numeric(5,2) | DEFAULT 100 | 默认欧盟以外比例（%） |

约束：
- 应用层保证三项之和为100。

### `fuel_cost_scenarios`（Fuel Cost模拟场景） — 租户级
继承 `TenantAwareEntity`
| 字段名 | 类型 | 约束 | 说明 |
|--------|------|------|------|
| id | uuid | PK |  |
| organizationId | uuid | FK -> organizations.id NOT NULL | 租户ID |
| name | varchar(100) | NOT NULL | 场景名称 |
| config | jsonb | NOT NULL | 存储案例配置、年份范围等 |

索引：
- `idx_fuel_scenarios_org` (organizationId)

---

## 9. 与脚手架现有表的关系

- **organizations**：已在脚手架中存在，我们直接使用。
- **users**：用户表，我们通过 `organization_members` 关联到组织。
- **roles/permissions**：可用于控制不同角色对航运模块的访问权限（如导入航次、查看报表等），需在权限系统中定义相应权限（如 `shipping:voyage:import`），并在菜单项中配置。

---

## 10. 关键设计说明

1. **多租户隔离**：所有租户级表（继承 `TenantAwareEntity`）都通过 `organizationId` 强制过滤，确保数据安全。
2. **全局+租户并存燃料主数据**：`fuel_types` 与 `fuel_prices` 同时支持全局与租户私有；查询时租户可使用“全局 + 本租户”数据集，且租户之间不共享私有数据。
3. **航次状态机**：`voyages.status` 支持 `unclaimed` → `claimed` → `calculated` → `locked`，便于跟踪处理流程。
4. **快照机制**：`calculation_snapshots` 存储计算结果及输入哈希，支持审计和重现。
5. **燃料类型与价格隔离**：租户可维护私有 `fuel_types/fuel_prices`，并可与全局数据一起使用；其他租户私有数据不可见。
6. **单位一致性**：所有数值字段单位已在注释中明确，计算引擎需确保转换正确。
7. **风力奖励因子映射**：当 `vessels.windAssist=true` 时，`windAssistDeviceType` 必须有值，并按 `wind_assist_factors` 中对应设备类型获取奖励因子。
