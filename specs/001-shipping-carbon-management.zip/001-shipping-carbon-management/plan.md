# Implementation Plan: Shipping Carbon Management MVP (DDD)

**Branch**: `001-shipping-carbon-management` | **Date**: 2026-03-09 | **Spec**: `specs/001-shipping-carbon-management/spec.md`
**Input**: Feature specification from `/specs/001-shipping-carbon-management/spec.md`

## Summary

本方案采用 DDD + 最终一致性：
1. 允许“无主航次”先入库，后续通过租期补偿认领。
2. 计算域纯函数化，严格与持久化实体解耦。
3. 通过快照与中间结果保证合规审计可追溯。

## Technical Context

**Language/Version**: TypeScript (`backend` TS 5.3.x, `speckit` TS 5.7.x)  
**Primary Dependencies**: NestJS, TypeORM, class-validator, multer(+xlsx parser), Next.js, React, Axios, Recharts  
**Storage**: PostgreSQL（实体 + 快照）  
**Testing**: Jest（unit/integration/e2e）+ Next lint/build  
**Target Platform**: Web + Linux/macOS server runtime  
**Project Type**: Monorepo web app (`backend` + `speckit` + `shared-schemas`)  
**Constraints**: `organizationId` 隔离、单位固定（ton/nm/MJ）、2025 ETS*0.7、Through Ice 仅展示  

## Constitution Check

- Monorepo boundary: PASS
- Contract-first + unit consistency: PASS
- Tenant isolation: PASS
- Deterministic + auditable calculation: PASS
- Evidence-driven delivery: PASS

## Project Structure

```text
backend/src/shipping-carbon/
├── domain/
│   ├── aggregates/
│   ├── entities/
│   ├── value-objects/
│   ├── services/
│   └── events/
├── application/
│   ├── services/
│   └── commands/
├── infrastructure/
│   ├── persistence/
│   ├── excel/
│   └── schedulers/
└── api/
    ├── controllers/
    └── dto/

speckit/src/app/[locale]/dashboard/shipping/
speckit/src/lib/api/shipping/
```

## Bounded Context Design

### Master Data Context
- Fuel Domain: LCV/Cf/WtT/Cslip 等因子与价格。
- Regulatory Domain: R/GHG Target/EUA/FX 等年度参数。
- Port Registry: Port Code + isEU。

### Shipping Domain
- Aggregate Root: `Vessel`。
- 子实体：`CharterPeriod`、`Voyage`。
- Voyage 状态：`UNCLAIMED`、`CLAIMED`（可后期认领）。

### Compliance Domain
- 纯计算引擎：CII/FuelEU/EU ETS/Fuel Cost。
- 快照：`ReportSnapshot`（含参数版本与中间结果）。
- 报告归档：`ReportCenterRecord`（导出文件留痕与再下载）。

## Phase 0: Domain Discovery & Strategy

目标：在编码前解决“一船多租户”和“数据溯源”悖论。

### 0.1 Ubiquitous Language
产出：`domain-glossary.md`（收录并强制术语）
- `Claimed Voyage`
- `Unclaimed Voyage`
- `Regulatory Snapshot`
- `Fuel Basis`

### 0.2 State Machine & Consistency
- 定义航次生命周期：`Unclaimed -> Claimed -> Calculated -> Locked`
- 明确租期重叠校验规则（在 `Vessel` 聚合内执行）
- 明确最终一致性：导入不阻塞，后续补偿认领

### 0.3 Context Mapping
- 设计 Shipping -> Compliance 的 ACL
- 计算引擎输入仅允许 VO/契约对象，不允许 ORM Entity

## Phase 1: Strategic Artifacts & Contracts

目标：定义不可变计算契约。

### 1.1 Value Objects
实现/定义：
- `Mass`
- `Distance`
- `Energy`
- `EmissionFactor`
- `GhgIntensity`

规则：
- 数学运算在 VO 或 Domain Service 内完成
- Application Service 不直接做裸 `number` 计算

### 1.2 Cross-Context Contracts
定义计算契约（如 `api/v1/compliance/calculate`）：
- Input: `VesselSpecs`, `VoyageData[]`, `FuelFactors`, `RegulatoryParams`
- Output: `IntermediateResults` + `FinalResults`

并补齐 `contracts/shipping-api.yaml` 对应接口。
并新增报告中心契约：导出即归档、归档列表查询、归档二次下载。

## Phase 2: Domain Implementation

目标：实现支持后期认领的聚合与纯计算引擎。

### 2.1 Shipping Domain - Vessel Aggregate
- 实现 `Vessel.addCharter()`
- 新租期加入时扫描 `UNCLAIMED` 航次并自动认领
- 触发 `VoyageClaimedEvent`

### 2.2 Compliance Domain - Pure Engines
- 实现 `CIIEngine`、`FuelEUEngine`、`ETSEngine`、`FuelCostEngine`
- 规则：禁止注入 Repository，输入输出纯对象

### 2.3 Application Layer - Calculation Coordinator
- 手动触发计算
- 定时任务重算
- 保存 `CalculationSnapshot/ReportSnapshot`

## Phase 3: Infrastructure & UI Integration

### 3.1 Reconciliation
- 实现 `VoyageReconciliationService`
- 处理租期变更导致的航次重新归属

### 3.2 Dashboards
- CII: `Required vs Attained` 图表
- FuelEU: 罚金与 GHG 差额
- EU ETS: 排放与 EUA 需求趋势
- Home/Scenario: 综合指标与情景对比

### 3.3 Report Center
- 新增报告中心页面与列表查询
- 导出操作改为“双写”：返回下载 + 归档入库
- 支持归档记录二次下载与筛选

## Risk Mitigation

- 法规参数中途修改：使用 `Regulatory Snapshot` 固化版本。
- 租期频繁变动：`VoyageClaimedEvent` 触发异步 `PendingRecalculation`。
- 多租户泄露：Repository 查询强制注入 `organizationId`。

## Complexity Tracking

| Violation | Why Needed | Simpler Alternative Rejected Because |
|-----------|------------|-------------------------------------|
| None | N/A | N/A |
