# Quickstart: Shipping Carbon Management MVP

## 1. Preconditions

1. 当前分支为 `001-shipping-carbon-management`
2. PostgreSQL 可用，`backend/.env` 正常配置
3. 已执行基础 seed（含组织、用户、权限）

## 2. Run Backend/Frontend

```bash
npm run dev
```

Frontend: `http://localhost:3050`  
Backend: `http://localhost:3051`

## 3. Create Basic Data

1. 登录租户账号
2. 创建 Ship
3. 创建 CharterParty（覆盖目标年份）
4. 维护系统常量（年份参数、港口、燃料参数）

## 4. Import Voyages

通过 `POST /api/shipping/voyages/import` 上传标准 `.xlsx`。

Expected:
- 返回成功/失败统计
- 错误行返回字段级原因

## 5. Generate Reports

1. 查询 CII 报表：`GET /api/shipping/reports/cii?shipId=...&year=2025`
2. 查询 FuelEU 报表：`GET /api/shipping/reports/fueleu?shipId=...&year=2025`
3. 查询 EU ETS 报表：`GET /api/shipping/reports/eu-ets?shipId=...&year=2025`
4. 查询 Fuel Cost 报表：
   `GET /api/shipping/reports/fuel-cost?shipId=...&startYear=2025&endYear=2050&fuelBasis=system`

## 6. Recalculate

触发重算：

```bash
curl -X POST http://localhost:3051/api/shipping/recalculate \
  -H 'Authorization: Bearer <token>' \
  -H 'Content-Type: application/json' \
  -d '{"shipId":"<ship-id>","year":2025,"framework":"cii","fuelBasis":"system"}'
```

Expected:
- 生成新快照版本
- 查询接口返回最新可用快照

## 7. Verification Commands

```bash
npm run lint --workspace backend
npm run test --workspace backend
npm run build --workspace backend
npm run lint --workspace speckit
npm run build --workspace speckit
```

## 8. Report Center Verification

1. 在任一报表页执行“手动导出”。
2. 验证浏览器收到导出文件。
3. 访问报告中心列表接口，确认新增一条归档记录。
4. 使用归档记录执行二次下载，确认文件可获取且内容一致。
