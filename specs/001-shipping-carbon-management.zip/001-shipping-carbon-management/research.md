# Research: Shipping Carbon Management MVP (DDD + Eventual Consistency)

## 1. Consistency Model Decision

Decision: 从“强一致导入即归属”改为“最终一致导入 + 后续认领”。

Rationale:
- 航次常先于租期到达，强一致会阻塞数据入库
- 允许 `UNCLAIMED` 航次可保证数据完整性和运营可见性

Consequence:
- 导入成功不等于罚金口径可计算
- 归属行为由租期变更触发补偿匹配

## 2. Bounded Context Decision

Decision: 三个上下文清晰隔离。

- Master Data Context：燃料/法规/港口
- Shipping Domain：Vessel 聚合 + Voyage 归属状态机
- Compliance Domain：纯计算 + 快照

Benefit:
- 燃料因子和港口逻辑不会污染计算引擎
- 计算模块可单测、可替换、可复算

## 3. Voyage State Machine

States:
- `UNCLAIMED`: 航次已入库，未匹配租期
- `CLAIMED`: 已归属租期（用于租户合规计量）

Transitions:
- Import with no matching charter -> `UNCLAIMED`
- Import with matching charter -> `CLAIMED`
- Add charter and matches existing unclaimed -> `UNCLAIMED -> CLAIMED`

## 4. Fuel Domain Independence

Decision: 系统燃料与租户燃料独立建模，按计算口径选择数据源，不互相覆盖。

Rules:
- `system` 口径：读取 SystemFuelType
- `tenant` 口径：读取 TenantFuelType
- 公式实现相同，仅参数来源不同

## 5. Snapshot and Audit Decision

Decision: Snapshot 记录“计算输入视图”，而非仅最终值。

Snapshot content:
- context key: organizationId, shipId, year, framework, fuelBasis
- input summary: voyage set hash, claim-state summary, master data version
- outputs: report payload
- metadata: calculatedAt, triggeredBy(manual|cron)

## 6. Trigger Strategy

Decision: 采用 Manual + Cron 双触发。

- Manual: API 指定 ship/year/framework
- Cron: 每日扫描过去 24h 内变更的 vessel（voyage/charter/master-data change）

## 7. Deferred Topics

- Pooling income 单位统一标准
- 极大规模导入异步化队列
- 更细粒度（月度）监管核算

## 8. Report Center Archiving Decision

Decision: 手动导出必须双写（用户下载 + 报告中心归档）。

Rationale:
- 满足合规留痕与复盘需求
- 避免导出文件仅存在于用户本地

Rules:
- 归档记录必须租户隔离
- 归档元数据至少包含报表类型、筛选参数、导出人、导出时间、文件信息
- 支持按记录二次下载
