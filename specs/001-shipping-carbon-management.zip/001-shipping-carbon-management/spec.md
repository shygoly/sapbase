# Feature Specification: 船舶碳排放管理系统（MVP）

**Feature Branch**: `001-shipping-carbon-management`  
**Created**: 2026-03-09  
**Status**: Draft  
**Input**: User description: "基于现有 NestJS + Next.js + Organization 多租户框架，构建船舶碳排放管理系统（CII/FuelEU/EU ETS/Fuel Cost）并参考现有 dashboard 形态完善规格。"

## User Scenarios & Testing *(mandatory)*

### User Story 1 - 船舶与航次数据管理（Priority: P1）

租户用户可以维护自己组织下的船舶、租期，并通过标准 Excel 模板导入航次数据，系统自动进行数据校验和租期归属。

**Why this priority**: 没有稳定的数据输入和租户隔离，就无法进行任何碳排放计算与报表展示。

**Independent Test**: 在单一租户下创建船舶与租期，导入包含 20 条航次的 xlsx；验证成功/失败条目、失败原因、以及租期自动归属结果。

**Acceptance Scenarios**:

1. **Given** 用户属于组织 A，且已创建船舶与租期，**When** 用户上传符合模板的 `.xlsx`，**Then** 系统成功导入合法航次并将每条航次自动绑定到唯一租期。
2. **Given** 导入文件中存在缺列、时间倒置、港口代码不存在或距离/油耗非法值，**When** 用户提交导入，**Then** 系统拒绝问题行并返回逐行错误明细，不影响其他合法行。
3. **Given** 同一船舶存在重叠租期，**When** 用户创建或更新租期，**Then** 系统阻止保存并提示冲突区间。

---

### User Story 2 - 年度合规计算与监管报表（Priority: P1）

租户用户可以按船舶与年份查看 CII、FuelEU、EU ETS 的年度计算结果和合规状态，系统支持快照存档与重算。

**Why this priority**: CII/FuelEU/EU ETS 是该系统核心业务价值，直接对应监管合规和经营决策。

**Independent Test**: 选定单船单年数据，分别调用 CII/FuelEU/EU ETS 报表接口并对照手工样本，验证公式、口径和快照落库。

**Acceptance Scenarios**:

1. **Given** 已导入某船某年航次且基础常量已维护，**When** 用户查询 CII 报表，**Then** 返回 Attained/Reference/Required/Ratio/Rating(A-E) 及合规状态。
2. **Given** FuelEU 参数与燃料因子齐备，**When** 用户查询 FuelEU 报表，**Then** 返回 GHG Actual/Target、差值、罚金、非合规年数与状态。
3. **Given** 港口 EU 属性与 EUA 价格已配置，**When** 用户查询 EU ETS 报表，**Then** 返回 YTD/Forecast 排放与配额需求，并按 EU 内100%、进出EU50%、EU外0% 计算。
4. **Given** 某船某年某框架已有快照，**When** 用户再次查询，**Then** 默认返回快照；**When** 用户触发重算，**Then** 生成新快照并保留可审计时间戳与参数版本信息。

---

### User Story 3 - 燃料成本分析与情景比较（Priority: P2）

租户用户可以在 Fuel Cost 报表中比较 2025-2050 三种燃料情景下的年度平均每吨成本与总成本，并可切换系统燃料口径/租户燃料口径。

**Why this priority**: 成本决策是合规之外的关键业务诉求，但可在核心合规报表后交付。

**Independent Test**: 配置三组情景参数后生成 Fuel Cost 报表，验证 Fuel + ETS + FuelEU Penalty + Pooling 组成项和口径切换差异。

**Acceptance Scenarios**:

1. **Given** 系统燃料库和租户燃料库都已维护，**When** 用户选择 `system` 口径计算，**Then** 报表使用系统燃料参数与价格。
2. **Given** 同一场景，**When** 用户切换到 `tenant` 口径，**Then** 报表改用租户燃料参数与价格，并保留相同算法结构。
3. **Given** 2025-2050 年度参数齐全，**When** 用户查询三情景比较，**Then** 返回各情景平均每吨成本与平均总成本，并展示关键构成项。

---

### User Story 4 - 监管看板与综合分析页面（Priority: P2）

用户可以在统一导航下访问 CII/FuelEU/EU ETS/Home Overview/Scenario Analysis 五类看板，查看指标卡、趋势图、明细表和告警信息。

**Why this priority**: 页面结构与可视化是业务落地可用性的关键，且你已给出对标页面形态。

**Independent Test**: 在同一租户、同一船舶、同一年份下依次访问 5 个页面，验证导航一致性、筛选一致性、指标和表格字段完整性。

**Acceptance Scenarios**:

1. **Given** 用户进入 CII Dashboard，**When** 选择船舶与年份，**Then** 页面显示 CII Rating、YTD Attained CII、Required CII、AER、CII 趋势图、评级变化图、年度明细表与 Compliance Warning。
2. **Given** 用户进入 FuelEU Dashboard，**When** 选择船舶与年份，**Then** 页面显示 GHG Target/Actual、GHG Difference、Expected Full Year Penalty、同比变化、Actual vs Target 图、Pooling Indicator 图与明细表。
3. **Given** 用户进入 EU ETS Dashboard，**When** 选择船舶与年份，**Then** 页面显示 YTD Emissions、YTD EUA Required、Full Year Forecast Emissions、Full Year Forecast EUA Required、年度趋势图与月度明细表。
4. **Given** 用户进入 Home Overview 或 Scenario Analysis，**When** 选择船舶与年份，**Then** 页面展示综合成本与排放关键指标（EUA/FuelEU Penalty/Forecast/GHG Difference）及趋势、月度明细。

---

### User Story 5 - 报告中心归档与再下载（Priority: P2）

用户在手动导出任意报表时，系统会将导出文件自动归档到“报告中心”，便于追溯和重复下载。

**Why this priority**: 满足合规留痕与运营复盘，避免导出文件只存在于用户本地。

**Independent Test**: 对 CII/FuelEU/EU ETS/Fuel Cost 分别执行一次手动导出，验证本地下载成功且报告中心新增对应记录并可再次下载。

**Acceptance Scenarios**:

1. **Given** 用户在报表页点击导出，**When** 导出任务完成，**Then** 系统同时返回下载文件并将同一文件写入报告中心归档。
2. **Given** 报告中心存在历史导出记录，**When** 用户打开报告中心，**Then** 可按船舶/年份/报表类型/导出时间筛选并查看记录。
3. **Given** 用户选择某条归档记录，**When** 点击下载，**Then** 系统返回当时归档的原始导出文件。

---

### Edge Cases

- 导入行命中 0 个租期或多个租期时，系统必须拒绝该行并返回可定位错误信息。
- `Shore Power Consumption` 为空时按 0 处理；非数值时判为非法。
- `Through Ice` 必须入库并可在报表/明细中展示，但任何计算结果不得受其影响。
- 同一船舶不同租户可存在相同 IMO，查询必须始终受 `organizationId` 隔离。
- FuelEU Penalty multiplier 使用租户人工填报历史；缺失上年记录时默认系数按 1 处理。
- 2025 年 EU ETS 必须应用 0.7 过渡系数；其他年份按 1.0。

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: 系统 MUST 基于现有 `organizationId` 实现租户隔离，任何 `ship/charter/voyage/report/penalty-history/tenant-fuels` 数据访问都必须组织内可见。
- **FR-002**: 系统 MUST 支持船舶主数据维护（船名、IMO、船型、GT、DWT、巡航速度可选、风力辅助标记、RFNBO相关标记）。
- **FR-003**: 系统 MUST 支持租期维护并阻止同一船舶租期重叠。
- **FR-004**: 系统 MUST 仅支持标准 `.xlsx` 航次模板导入，不支持 CSV/自由列映射。
- **FR-005**: 系统 MUST 对导入数据执行严格校验：必填列、港口代码、时间顺序、距离单位（海里）、油耗单位（吨）、岸电单位（MJ）。
- **FR-006**: 系统 MUST 对每条航次按时间自动归属到唯一租期，无法唯一归属时拒绝该行并返回错误原因。
- **FR-007**: 系统 MUST 实现 CII 年度计算：Attained/Reference/Required/Ratio/Rating(A-E)，并支持船型分母规则（DWT 或 GT）。
- **FR-008**: 系统 MUST 实现 FuelEU 年度计算：WtT、TtW、RWD_wind、RWD_RFNBO、GHG Actual/Target、Penalty。
- **FR-009**: 系统 MUST 采用租户人工填报的年度超排记录作为 FuelEU penalty multiplier 的唯一来源。
- **FR-010**: 系统 MUST 实现 EU ETS 年度计算，采用航段口径：EU内=100%，进出EU=50%，EU外=0%。
- **FR-011**: 系统 MUST 在 2025 年 EU ETS 计算应用过渡系数 0.7。
- **FR-012**: 系统 MUST 提供 Fuel Cost 报表，覆盖 2025-2050 三情景，输出平均每吨成本与平均总成本。
- **FR-013**: 系统 MUST 支持 Fuel Cost 在 `system` 与 `tenant` 两种燃料口径间切换计算。
- **FR-014**: 系统 MUST 为 CII、FuelEU、Fuel Cost 提供按 `shipId + year + framework (+ fuelBasis)` 的结果快照存储。
- **FR-015**: 系统 MUST 支持显式重算，并保留快照时间戳及参数版本元数据以满足审计。
- **FR-016**: 系统 MUST 提供以下后端 API：
  - `/api/shipping/ships`
  - `/api/shipping/charters`
  - `/api/shipping/voyages/import`
  - `/api/shipping/voyages`
  - `/api/shipping/constants/*`
  - `/api/shipping/tenant-fuels`
  - `/api/shipping/penalty-history`
  - `/api/shipping/recalculate`
  - `/api/shipping/reports/cii`
  - `/api/shipping/reports/fueleu`
  - `/api/shipping/reports/fuel-cost`
- **FR-017**: 系统 MUST 提供 CII Dashboard 页面，包含顶部主导航、面包屑、船舶选择、评级卡片、趋势图、评级变化图、年度明细表和 Compliance Warning。
- **FR-018**: 系统 MUST 提供 FuelEU Dashboard 页面，包含 GHG Target/Actual、GHG Difference、Expected Full Year Penalty、同比变化、对比图、Pooling 指示与年度明细表。
- **FR-019**: 系统 MUST 提供 EU ETS Dashboard 页面，包含 YTD/Forecast 指标卡、年度排放图、Time Charter Allocation、EUA Required 趋势与月度明细表。
- **FR-020**: 系统 MUST 提供 Home Overview 与 Scenario Analysis 两个综合页面，支持船舶与年份选择，并展示 EUA/FuelEU Penalty/Forecast/GHG Difference 与趋势、月度明细。
- **FR-021**: 系统 MUST 在所有 Dashboard 页面保持统一导航、面包屑与筛选交互模型。
- **FR-022**: 系统 MUST 在报表和明细中展示 `Through Ice` 字段，但不得将其用于任何当前版本计算公式。
- **FR-023**: 系统 MUST 将航次状态建模为 `UNCLAIMED` 与 `CLAIMED`：导入时无法匹配租期的航次进入 `UNCLAIMED`，新增租期后系统 MUST 自动尝试认领并转为 `CLAIMED`。
- **FR-024**: 系统 MUST 维持系统燃料库与租户燃料库的独立性，租户燃料不得覆盖系统燃料；计算时仅通过 `fuelBasis` 选择参数来源。
- **FR-025**: 系统 MUST 提供报告中心（Report Center），存储用户手动导出的报表文件及元数据（报表类型、船舶、年份、导出人、导出时间、参数摘要、文件地址）。
- **FR-026**: 系统 MUST 在用户手动导出报表时执行“双写”：一份返回给用户下载，另一份归档至报告中心。
- **FR-027**: 系统 MUST 支持报告中心列表查询与二次下载，并保持租户隔离（仅可访问本组织导出归档）。

### Key Entities *(include if feature involves data)*

- **Ship**: 租户内船舶主数据，含 IMO、船型、GT、DWT、风力辅助与燃料策略相关属性。
- **CharterParty**: 船舶在某租户下的租期区间，约束同船租期不重叠。
- **Voyage**: 航次主记录，含起止港、时间、距离、岸电、到港目的、Through Ice。
- **VoyageFuelConsumption**: 航次燃料明细（主机/辅机），支持多燃料行归一化。
- **SystemFuelType**: 系统级燃料参数与价格（LCV、排放因子、Cf、Cslip、WtT 因子、年度价格等）。
- **TenantFuelType**: 租户自定义燃料库与价格参数（独立于系统燃料库）。
- **YearParameter**: 年度常数（R、GHG Target、Penalty 单价、EUA Price、汇率等）。
- **CiiShipTypeParameter**: CII 船型参数（a、c、d1-d4、分母类型）。
- **Port**: 港口主数据（港口代码、名称、国家/区域、是否 EU）。
- **WindRewardFactor**: 风力辅助设备类型到 `RWD_wind` 的映射。
- **PenaltyHistory**: 租户人工填报的船舶年度超排记录。
- **ReportSnapshot**: 按框架和年份固化的计算结果及参数版本快照。
- **ReportCenterRecord**: 报告中心归档记录，关联导出文件、报表类型、筛选参数和导出人。

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: 在标准模板导入中，系统可对 1000 行航次数据完成解析、校验并返回逐行结果，且错误行可定位到行号与字段。
- **SC-002**: 对给定样例数据，CII/FuelEU/EU ETS 计算结果与基准样本误差不超过 0.5%（或绝对误差阈值按报表字段约定）。
- **SC-003**: 任一租户无法通过 API 或 UI 读取其他租户的船舶、航次、报表与快照数据（跨租户访问失败率 100%）。
- **SC-004**: Fuel Cost 在 `system` 与 `tenant` 口径切换后，结果能够稳定返回且至少有一个成本构成项发生可解释变化。
- **SC-005**: CII/FuelEU/EU ETS/Home/Scenario 五个页面均具备统一导航和可用筛选器，并在单船单年场景下完成首屏数据加载。
- **SC-006**: 用户每次手动导出后，报告中心在 5 秒内可查询到对应归档记录并可再次下载。
