# Tasks: Shipping Carbon Management MVP (DDD)

**Input**: Design documents from `/specs/001-shipping-carbon-management/`  
**Prerequisites**: `plan.md`, `spec.md`, `research.md`, `data-model.md`, `contracts/shipping-api.yaml`  
**Tests**: 本任务包含测试任务，按“先写失败测试再实现”执行。  
**Organization**: 按用户故事分组，保证每个故事可独立实现和验证。

## Format: `[ID] [P?] [Story] Description`

- `[P]`: 可并行执行（不同文件、无直接依赖）
- `[Story]`: `US1`..`US5`

## Phase 1: Setup (Shared Infrastructure)

- [ ] T001 [P] [Setup] 创建后端 DDD 模块骨架：`backend/src/shipping-carbon/{domain,application,infrastructure,api}` 与子目录。
- [ ] T002 [P] [Setup] 创建前端路由骨架：`speckit/src/app/[locale]/dashboard/shipping/**/page.tsx`。
- [ ] T003 [P] [Setup] 创建 API 客户端骨架：`speckit/src/lib/api/shipping/{ships,charters,voyages,constants,reports,report-center}.api.ts`。
- [ ] T061 [P] [Setup] 建立 OpenAPI -> TypeScript 客户端生成流程（脚本或命令），输出到 `speckit/src/lib/api/generated/shipping/`，并在手写客户端中复用生成类型。
- [ ] T004 [P] [Setup] 在 `speckit/src/lib/api/index.ts` 导出 shipping API 客户端。
- [ ] T005 [P] [Setup] 在 `backend/src/app.module.ts` 注册 `ShippingCarbonModule`。

## Phase 2: Foundational (Blocking Prerequisites)

- [ ] T006 [P] [Foundation] 新建迁移：`backend/src/migrations/*-CreateShippingCarbonCoreTables.ts`（vessels/charter_periods/voyages/voyage_fuels）。
- [ ] T007 [P] [Foundation] 新建迁移：`backend/src/migrations/*-CreateFuelAndRegulationTables.ts`（fuel_types/fuel_prices/regulation_params/ports/...）。
- [ ] T008 [P] [Foundation] 新建迁移：`backend/src/migrations/*-CreateSnapshotsAndReportCenterTables.ts`（calculation_snapshots/report_center_records/fueleu_compliance_history）。
- [ ] T009 [Foundation] 实现实体映射：`backend/src/shipping-carbon/infrastructure/persistence/entities/*.entity.ts`（按 `data-model.md`）。
- [ ] T010 [P] [Foundation] 实现 Value Objects：`backend/src/shipping-carbon/domain/value-objects/{mass,distance,energy,emission-factor,ghg-intensity}.vo.ts`。
- [ ] T011 [P] [Foundation] 实现领域事件定义：`backend/src/shipping-carbon/domain/events/{voyage-added,voyage-claimed}.event.ts`。
- [ ] T012 [Foundation] 实现 ACL 输入模型：`backend/src/shipping-carbon/application/contracts/compliance-input.contract.ts`（禁止 ORM 实体直入引擎）。
- [ ] T013 [Foundation] 在 `backend/src/seeds/mock-data.seed.ts` 增加 shipping 权限与菜单（含 report center），采用细粒度命名规范：
  - `shipping:ship:{create|read|update|delete}`
  - `shipping:charter:{create|read|update|delete}`
  - `shipping:voyage:{import|create|read|update|delete}`
  - `shipping:report:{cii|fueleu|eu-ets|fuel-cost|overview|scenario}:view`
  - `shipping:report-center:{read|download|delete}`
  - `shipping:constants:{read|write}`
- [ ] T057 [Foundation] 初始化航运基础主数据：`backend/src/seeds/shipping-carbon.seed.ts`（ports、fuel_types、ship_type_params、regulation_params、gwp_values、csf_values、wind_assist_factors）。

## Phase 3: User Story 1 - 船舶与航次数据管理 (Priority: P1) 🎯

**Goal**: 完成船舶/租期/航次导入与 `UNCLAIMED/CLAIMED` 认领机制。  
**Independent Test**: 导入包含合法/非法行的 xlsx，验证行级错误、无主航次、后续租期认领。

### Tests for US1

- [ ] T014 [P] [US1] 新增导入校验单元测试：`backend/src/shipping-carbon/application/services/import-voyage.service.spec.ts`。
- [ ] T015 [P] [US1] 新增聚合行为测试：`backend/src/shipping-carbon/domain/aggregates/vessel.aggregate.spec.ts`（addVoyage/addCharter/reconcile）。
- [ ] T016 [P] [US1] 新增 e2e：`backend/test/shipping-carbon-import.e2e-spec.ts`（部分成功导入、状态流转）。

### Implementation for US1

- [ ] T017 [US1] 实现 `Vessel` 聚合根：`backend/src/shipping-carbon/domain/aggregates/vessel.aggregate.ts`。
- [ ] T018 [US1] 实现船舶 CRUD API：`backend/src/shipping-carbon/api/controllers/ships.controller.ts` + `application/services/ships.service.ts`。
- [ ] T019 [US1] 实现租期 CRUD 与不重叠校验：`backend/src/shipping-carbon/api/controllers/charters.controller.ts` + `application/services/charters.service.ts`。
- [ ] T020 [US1] 实现 xlsx 导入器：`backend/src/shipping-carbon/infrastructure/excel/voyage-xlsx-parser.ts`。
- [ ] T021 [US1] 实现导入命令处理：`backend/src/shipping-carbon/application/commands/import-voyage-excel.handler.ts`，每条导入航次即时调用 `reconcileVoyageWithCharter` 尝试认领。
- [ ] T022 [US1] 实现航次查询 API：`backend/src/shipping-carbon/api/controllers/voyages.controller.ts`（shipId/year/charterId 过滤）。
- [ ] T023 [US1] 前端完成 Ships/Charters/Voyages 页面：`speckit/src/app/[locale]/dashboard/shipping/{ships,charters,voyages}/page.tsx`。
- [ ] T024 [US1] 前端实现导入对话框与失败明细展示：`speckit/src/components/shipping/import-dialog.tsx`。

## Phase 4: User Story 2 - 年度合规计算与监管报表 (Priority: P1)

**Goal**: 完成 CII/FuelEU/EU ETS 计算、快照、手动+定时重算。  
**Independent Test**: 单船单年可出三类监管报表，重算后快照可追溯。

### Tests for US2

- [ ] T025 [P] [US2] CII 引擎单测：`backend/src/shipping-carbon/domain/services/cii-engine.service.spec.ts`。
- [ ] T026 [P] [US2] FuelEU 引擎单测：`backend/src/shipping-carbon/domain/services/fueleu-engine.service.spec.ts`。
- [ ] T027 [P] [US2] EU ETS 引擎单测：`backend/src/shipping-carbon/domain/services/ets-engine.service.spec.ts`。
- [ ] T028 [P] [US2] 快照与重算集成测试：`backend/test/shipping-carbon-recalculate.e2e-spec.ts`。

### Implementation for US2

- [ ] T029 [US2] 实现纯计算引擎：`backend/src/shipping-carbon/domain/services/{cii,fueleu,ets}-engine.service.ts`。
- [ ] T030 [US2] 实现计算协调器：`backend/src/shipping-carbon/application/services/calculation-coordinator.service.ts`（读取 `fueleu_compliance_history` 作为 penalty multiplier 输入，不自动写入该历史表）。
- [ ] T031 [US2] 实现定时重算任务：`backend/src/shipping-carbon/infrastructure/schedulers/nightly-reconciliation.job.ts`（兜底包含未认领航次批量认领 + 相关报表重算标记）。
- [ ] T032 [US2] 实现快照仓储：`backend/src/shipping-carbon/infrastructure/persistence/repositories/report-snapshot.repository.ts`。
- [ ] T033 [US2] 实现重算接口：`backend/src/shipping-carbon/api/controllers/recalculate.controller.ts`。
- [ ] T034 [US2] 实现 CII/FuelEU/EU ETS 报表接口：`backend/src/shipping-carbon/api/controllers/reports.controller.ts`。
- [ ] T035 [US2] 前端实现 CII/FuelEU/EU ETS Dashboard：`speckit/src/app/[locale]/dashboard/shipping/reports/{cii,fueleu,eu-ets}/page.tsx`。
- [ ] T060 [US2] 实现 FuelEU 超排历史手工维护接口：`backend/src/shipping-carbon/api/controllers/fueleu-compliance-history.controller.ts` + `application/services/fueleu-compliance-history.service.ts`（租户按 vessel/year 录入或更新是否超排与系数）。

## Phase 5: User Story 3 - Fuel Cost 情景分析 (Priority: P2)

**Goal**: 完成 2025-2050 三情景与 `system/tenant` 口径切换。  
**Independent Test**: 同一场景切换口径后结果变化可解释且稳定。

### Tests for US3

- [ ] T036 [P] [US3] Fuel Cost 引擎单测：`backend/src/shipping-carbon/domain/services/fuel-cost-engine.service.spec.ts`。
- [ ] T037 [P] [US3] 口径切换集成测试：`backend/test/shipping-carbon-fuel-basis.e2e-spec.ts`。

### Implementation for US3

- [ ] T038 [US3] 实现 Fuel Cost 纯计算引擎：`backend/src/shipping-carbon/domain/services/fuel-cost-engine.service.ts`。
- [ ] T039 [US3] 实现 `fuelBasis` 参数分发与数据源选择：`backend/src/shipping-carbon/application/services/fuel-basis-selector.service.ts`。
- [ ] T040 [US3] 实现 Fuel Cost 报表接口：`backend/src/shipping-carbon/api/controllers/fuel-cost.controller.ts`。
- [ ] T041 [US3] 前端实现 Fuel Cost 页面：`speckit/src/app/[locale]/dashboard/shipping/reports/fuel-cost/page.tsx`。

## Phase 6: User Story 4 - 监管看板与综合分析页面 (Priority: P2)

**Goal**: 完成统一导航、筛选、图表与表格体验。  
**Independent Test**: 五个页面在同租户同船同年下均可一致加载与筛选。

### Tests for US4

- [ ] T042 [P] [US4] 前端页面加载与筛选 smoke 测试：`tests/shipping-dashboard-smoke.test.js`。
- [ ] T062 [P] [US4] 后端综合看板集成测试：`backend/test/shipping-dashboard-overview.e2e-spec.ts`（校验 `/api/shipping/reports/overview` 或等效接口的数据结构与核心业务字段）。

### Implementation for US4

- [ ] T043 [US4] 新增 shipping 菜单组与路由映射：`speckit/src/config/default-menu-items.ts`。
- [ ] T044 [US4] 实现 Home Overview/Scenario Analysis 页面：`speckit/src/app/[locale]/dashboard/shipping/reports/{home-overview,scenario-analysis}/page.tsx`。
- [ ] T045 [US4] 实现共享筛选栏与指标卡组件：`speckit/src/components/shipping/{search-filter-bar,metric-card,chart-card}.tsx`。
- [ ] T046 [US4] 实现趋势图与占比图组件：`speckit/src/components/shipping/{trend-chart,donut-chart}.tsx`。
- [ ] T047 [US4] 实现通用表格行操作组件：`speckit/src/components/shipping/{data-table,row-actions,status-switch-cell}.tsx`。

## Phase 7: User Story 5 - 报告中心归档与再下载 (Priority: P2)

**Goal**: 实现手动导出双写（下载+归档）与报告中心。  
**Independent Test**: 每次导出后 5 秒内可在报告中心查询并二次下载。

### Tests for US5

- [ ] T048 [P] [US5] 导出双写单测：`backend/src/shipping-carbon/application/services/report-export.service.spec.ts`。
- [ ] T049 [P] [US5] 报告中心 e2e：`backend/test/shipping-report-center.e2e-spec.ts`。

### Implementation for US5

- [ ] T050 [US5] 实现导出服务（生成文件+归档记录）：`backend/src/shipping-carbon/application/services/report-export.service.ts`。
- [ ] T051 [US5] 实现报告中心仓储与实体：`backend/src/shipping-carbon/infrastructure/persistence/{entities/report-center-record.entity.ts,repositories/report-center.repository.ts}`。
- [ ] T052 [US5] 实现导出接口与报告中心接口：`backend/src/shipping-carbon/api/controllers/{report-export,report-center}.controller.ts`。
- [ ] T053 [US5] 前端实现 ExportButton 与报告中心页面：`speckit/src/components/shipping/export-button.tsx` + `speckit/src/app/[locale]/dashboard/shipping/report-center/page.tsx`。
- [ ] T058 [US5] 实现文件存储服务：`backend/src/shipping-carbon/infrastructure/storage/report-file-storage.service.ts`（支持本地路径配置，预留 S3 扩展）。
- [ ] T059 [US5] 在导出服务中接入存储配置：`backend/src/shipping-carbon/application/services/report-export.service.ts` + `backend/.env.example`（导出目录/公共访问前缀）。

## Phase 8: Polish & Cross-Cutting Concerns

- [ ] T054 [P] [Polish] 更新 API 文档：运行 `npm run generate:docs --workspace backend` 并同步 `backend/openapi.*`。
- [ ] T055 [P] [Polish] 更新开发文档：`docs/shipping-carbon/`（导入模板、字段字典、报表口径、报告中心）。
- [ ] T056 [Polish] 执行全链路验证并记录结果到 `specs/001-shipping-carbon-management/quickstart.md`。

## Dependencies & Execution Order

- Setup (Phase 1) -> Foundation (Phase 2) -> US1/US2/US3/US4/US5 -> Polish
- US1 完成后才能稳定支撑 US2/US3
- US5 依赖 US2/US3 报表输出能力

## Parallel Opportunities

- T006/T007/T008 可并行（不同迁移文件）
- T025/T026/T027 可并行（不同引擎单测）
- T043/T045/T046/T047 可并行（前端不同组件）
- T050/T051 可并行（服务与仓储分离）
- T057 可与 T006/T007/T008 并行（数据与结构分离）
